C - Stacks, Queues - LIFO, FIFO.
